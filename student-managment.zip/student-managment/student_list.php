<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit();
}
require_once 'classes/Database.php';
// Initialize database connection and Admin class
$db = (new Database())->getConnection();
include 'includes/head.php'; 
?>

<!-- Include Bootstrap 5 and DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">


<div id="content" class="p-4 p-md-0">
    <?php include 'includes/header.php'; ?>
    <div class="p-md-5"> 
  <?php  if (isset($_SESSION['message'])) {
    echo "<div style='color: green;'>" . $_SESSION['message'] . "</div>";
    unset($_SESSION['message']);
    }?>
        <div class="d-flex justify-content-between mb-4">
            <h2 class="mb-4">Task Reports</h2>
            <div>
                <a href="student_add.php" class="btn btn-success btn-sm">Add New Student</a>
                <a href="student_list_download_csv.php" class="btn btn-primary btn-sm">Download Tasks Report</a>
            </div>
        </div>

        <div class="table-responsive">
            <table id="taskTable" class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Mobile</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>Address</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php   
                $result = $db->query("SELECT * FROM students");
                while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['name'] ?></td>
                        <td><?= $row['age'] ?></td>
                        <td><?= $row['mobile'] ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['gender'] ?></td>
                        <td><?= $row['address'] ?></td>
                        <td><?= $row['status'] ?></td>
                        <td>
                            <a href="student_edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                            <a href="delete_student.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- Include jQuery, Bootstrap 5, and DataTables JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>

<!-- Initialize DataTable -->
<script>
    $(document).ready(function() {
        $('#taskTable').DataTable({
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true
        });
    });
</script>
