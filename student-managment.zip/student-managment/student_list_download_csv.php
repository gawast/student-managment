<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit();
}

require_once 'classes/Database.php';

// Initialize database connection
$db = (new Database())->getConnection();
$query = "SELECT * FROM students";
$result = $db->query($query);

// Set headers for downloading CSV file
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=student_list_report.csv');
header('Pragma: no-cache');
header('Expires: 0');

// Open output stream for CSV
$output = fopen('php://output', 'w');

// Output column headings
fputcsv($output, array('ID', 'Name', 'Age', 'Mobile', 'Email', 'Gender', 'Address', 'Status'));

// Fetch rows and output them as CSV lines
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Write each row to CSV
        fputcsv($output, array(
            $row['id'],
            $row['name'],
            $row['age'],
            $row['mobile'],
            $row['email'],
            $row['gender'],
            $row['address'],
            $row['status']
        ));
    }
} else {
    // If no data is found, output an empty CSV row
    fputcsv($output, array('No data found.'));
}

// Close output stream
fclose($output);

// Close database connection
$db->close();
