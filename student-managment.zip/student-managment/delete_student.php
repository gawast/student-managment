<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit();
}
require_once 'classes/Database.php';
$db = (new Database())->getConnection();
$id = $_GET['id'];
$stmt = $db->prepare("DELETE FROM students WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$_SESSION['message'] = "Student deleted successfully.";
header("Location: student_list.php"); 
?>