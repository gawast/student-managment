<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}
require_once 'classes/Database.php';
$db = (new Database())->getConnection();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $status = $_POST['status'];

    $stmt = $db->prepare("INSERT INTO students (name, age, mobile, email, gender, address, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisssss", $name, $age, $mobile, $email, $gender, $address, $status);
    $stmt->execute();
    $_SESSION['message'] = "Student added successfully.";
    header("Location: student_list.php");
}
?>

<?php include 'includes/head.php'; ?>
   
<div id="content" class="p-4 p-md-0">
    <?php include 'includes/header.php'; ?>
    <div class="p-md-5">
        <h2 class="mb-4">Add Student</h2>
        <form method="POST" class="bg-light p-4 rounded shadow-sm">
            <div class="row">
                <div class="form-group mb-3 col-md-6">
                    <label>Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="form-group mb-3 col-md-6">
                    <label>Age</label>
                    <input type="text" name="age" class="form-control" required>
                </div>
            </div>

            <div class="row">
                <div class="form-group mb-3 col-md-6">
                    <label>Mobile</label>
                    <input type="text" name="mobile" class="form-control" required>
                </div>
                <div class="form-group mb-3 col-md-6">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
            </div>

            <div class="row">
                <div class="form-group mb-3 col-md-6">
                    <label>Gender</label>
                    <select name="gender" class="form-control">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div class="form-group mb-3 col-md-6">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="form-group mb-3 col-md-12">
                    <label>Address</label>
                    <textarea name="address" class="form-control"></textarea>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>


<?php include 'includes/footer.php'; ?> 