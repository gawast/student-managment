<?php
class User {
    protected $db;
    protected $email;
    protected $password;
    private $message = "";
    public function __construct($db, $email, $password) {
        $this->db = $db;
        $this->email = $email;
        $this->password = $password;
    }

    public function getMessage() {
        return $this->message;
    }
    public function createUser($username, $newemail,$hashedPassword) {
        // Check if the email already exists
        $query = "SELECT * FROM users WHERE email = '$newemail'";
        $result = $this->db->query($query);

        if ($result->num_rows > 0) {
            $this->message = "Info: email '$newemail' already exists.";
            return;
        }

        // Proceed to insert the new user
        $insertQuery = "INSERT INTO users (username,email, password) VALUES ('$username', '$newemail','$hashedPassword')";

        if ($this->db->query($insertQuery) === TRUE) {
            $this->message = "User created successfully ";
        } else {
            $this->message = "Error: " . $this->db->error;
        }
    }

   public function login() {
    $email = mysqli_real_escape_string($this->db, $this->email);
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($this->db, $query);   
    $user = mysqli_fetch_assoc($result);
    if ($user && password_verify($this->password, $user['password'])) {
        $_SESSION['loggedin'] = true;
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['email'];
        return true;
    }
    return false;
}

}
?>
