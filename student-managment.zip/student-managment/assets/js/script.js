document.getElementById('sidebarCollapse').addEventListener('click', function () {
    document.getElementById('sidebar-wrapper').classList.toggle('active');
});
