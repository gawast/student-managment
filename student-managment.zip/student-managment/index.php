<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit();
}
?>
<?php include 'includes/head.php'; ?>
   
        <div id="content" class="p-4 p-md-0">
            <?php include 'includes/header.php'; ?>
            <h2 class="mb-4" style="margin-left: 20px;">Dashboard</h2>
            <p style="margin-left: 20px;">Welcome to the Admin Panel!</p>
        </div>
<?php include 'includes/footer.php'; ?>